const API = "http://localhost:5000/api";



// گرفتن تعداد محصولات

async function loadDashboard(){


    try{


        const products = await fetch(

            API + "/products"

        );


        const productData = await products.json();



        document.getElementById(

            "productsCount"

        ).innerHTML = productData.length;





    }catch(error){


        console.log(error);


    }



}





// اضافه کردن فعالیت

function addActivity(text){


    const table = document.getElementById(

        "activity"

    );



    if(!table) return;




    table.innerHTML += `


    <tr>

    <td>
    سیستم
    </td>


    <td>
    ${text}
    </td>


    <td>
    ${new Date().toLocaleDateString("fa-AF")}
    </td>


    </tr>


    `;



}





loadDashboard();