const API = "http://localhost:5000/api";

let uploadedImages = [];



// آپلود عکس از گالری

async function uploadImages(){


    const files = document.getElementById("image").files;


    if(files.length === 0){

        return [];

    }



    const formData = new FormData();



    for(let i = 0; i < files.length; i++){


        formData.append(

            "images",

            files[i]

        );

    }




    const response = await fetch(

        API + "/upload/multiple",

        {

            method:"POST",

            body:formData

        }

    );



    const data = await response.json();



    uploadedImages = data.images;



    return data.images;


}









// اضافه کردن محصول نهایی

async function addProduct(){


    try{


        const images = await uploadImages();




        const product = {


            productCode:

            document.getElementById("productCode").value,



            name:

            document.getElementById("name").value,



            category:

            document.getElementById("category").value,



            purchasePrice:

            Number(

            document.getElementById("purchasePrice").value

            ),



            marketPrice:

            Number(

            document.getElementById("marketPrice").value

            ),



            storePrice:

            Number(

            document.getElementById("storePrice").value

            ),



            stock:

            Number(

            document.getElementById("stock").value

            ),



            images:images



        };







        const response = await fetch(

            API + "/products/add",

            {


                method:"POST",


                headers:{


                    "Content-Type":"application/json"


                },


                body:JSON.stringify(product)



            }

        );





        const data = await response.json();



        alert(

            data.message

        );



        loadProducts();



    }catch(error){



        alert(

            "خطا در ثبت محصول"

        );



        console.log(error);


    }


}









// نمایش محصولات

async function loadProducts(){


    try{


        const response = await fetch(

            API + "/products"

        );



        const products = await response.json();




        const table = document.getElementById(

            "products"

        );



        table.innerHTML="";




        products.forEach(product=>{


            table.innerHTML += `



            <tr>


            <td>

            ${product.productCode}

            </td>



            <td>

            ${product.name}

            </td>




            <td>

            ${product.category}

            </td>




            <td>

            ${product.marketPrice}

            AFN

            </td>




            <td>

            ${product.storePrice}

            AFN

            </td>




            <td>

            ${product.stock}

            </td>



            </tr>


            `;


        });



    }catch(error){


        console.log(error);


    }


}








loadProducts();