const API = "http://localhost:5000/api";




// ذخیره تنظیمات

async function saveSettings(){


    const settings = {


        storeName:

        document.getElementById(

            "storeName"

        ).value,



        storePhone:

        document.getElementById(

            "storePhone"

        ).value,



        storeAddress:

        document.getElementById(

            "storeAddress"

        ).value,



        currency:

        document.getElementById(

            "currency"

        ).value,



        online:

        document.getElementById(

            "online"

        ).value



    };




    try{


        const response = await fetch(

            API + "/settings",

            {


                method:"POST",


                headers:{


                    "Content-Type":

                    "application/json"


                },


                body:JSON.stringify(settings)



            }


        );





        const data = await response.json();



        alert(

            data.message

        );




    }catch(error){


        console.log(error);


    }


}









// اضافه کردن دسته‌بندی

function addCategory(){


    const name = document.getElementById(

        "newCategory"

    ).value;




    if(!name){


        return;


    }




    const list = document.getElementById(

        "categories"

    );



    list.innerHTML += `


    <li>

    ${name}

    </li>


    `;



    document.getElementById(

        "newCategory"

    ).value="";


}