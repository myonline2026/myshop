const API = "http://localhost:5000/api";


let cart = [];

let customer = null;





// جستجوی مشتری

async function searchCustomer(){


    const phone = document.getElementById(
        "customerPhone"
    ).value;



    try{


        const response = await fetch(

            API + "/auth/search/" + phone

        );



        const data = await response.json();



        customer = data;



        document.getElementById(
            "customerInfo"
        ).innerHTML = `

        نام مشتری:
        ${data.name}

        `;



    }catch(error){


        alert(
            "مشتری پیدا نشد"
        );


    }


}







// اضافه کردن جنس به فاکتور

async function addToCart(){


    const code = document.getElementById(
        "productCode"
    ).value;



    const quantity = Number(

        document.getElementById(
            "quantity"
        ).value

    );




    try{


        const response = await fetch(

            API + "/products"

        );



        const products = await response.json();



        const product = products.find(

            p=>p.productCode===code

        );



        if(!product){


            alert(
                "جنس پیدا نشد"
            );


            return;

        }




        const total = product.storePrice * quantity;



        cart.push({

            productId:product._id,

            name:product.name,

            quantity:quantity,

            price:product.storePrice,

            total:total

        });



        showCart();



    }catch(error){


        console.log(error);


    }


}







// نمایش فاکتور

function showCart(){


    const box = document.getElementById(
        "cart"
    );


    box.innerHTML="";



    let sum = 0;



    cart.forEach(item=>{


        sum += item.total;



        box.innerHTML += `

        <tr>

        <td>
        ${item.name}
        </td>


        <td>
        ${item.quantity}
        </td>


        <td>
        ${item.price}
        </td>


        <td>
        ${item.total}
        </td>


        </tr>

        `;


    });



    document.getElementById(
        "total"
    ).innerHTML = sum;


}








// ثبت فروش

async function submitOrder(){



    if(!customer){


        alert(
            "اول مشتری را انتخاب کنید"
        );


        return;

    }





    const totalAmount = cart.reduce(

        (sum,item)=>

        sum + item.total,

        0

    );





    await fetch(

        API + "/orders/create",

        {


            method:"POST",


            headers:{


                "Content-Type":
                "application/json"


            },


            body:JSON.stringify({


                customerId:
                customer._id,


                products:
                cart,


                totalAmount:
                totalAmount



            })


        }

    );



    alert(
        "فروش ثبت شد"
    );



    cart=[];

    showCart();


}